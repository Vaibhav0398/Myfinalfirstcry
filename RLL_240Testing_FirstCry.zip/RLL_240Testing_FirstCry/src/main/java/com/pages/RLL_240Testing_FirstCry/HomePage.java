package com.pages.RLL_240Testing_FirstCry;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
public class HomePage {
	WebDriver driver;
	
	By LoginButton = By.xpath("//*[text()='Login /']");
	By cartIcon = By.xpath("//a[@href='https://checkout.firstcry.com/pay']/span[@class='M14_61 pos-rel']/span[@class='prodQuant cart-icon B18_orange paddinglft']");
	By SearchItem = By.xpath("//input[@id=\"search_box\"]");
	By searchIcon = By.xpath("//span[@class=\"search-button\"]");
	
	public HomePage(WebDriver driver)
	{
		this.driver=driver;
	}
	
	public void LaunchFirstCry()
	{
		driver.manage().window().maximize();
		driver.get("https://www.firstcry.com/");
		
	}
	
	public void loginbuttonclick()
	{
		driver.findElement(LoginButton).click();
	}
	
	public void ClickCartIcon()
	{
		driver.findElement(cartIcon).click();
	}
	
	public void searchItem()
	{
		driver.findElement(SearchItem).click();
		driver.findElement(SearchItem).sendKeys("Shirts");
	}
 
	public void clickSearchIcon()
	{
		driver.findElement(searchIcon).click();
	}
}
