package com.pages.RLL_240Testing_FirstCry;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class FindStoresPage 
{
	WebDriver driver;
	By Stores_and_Preschool = By.xpath("//span[@class='anch'][contains(text(),'Stores & Preschools')]");
	By Find_Stores= By.xpath("//span[@class='anch'][contains(text(),'Find Stores')]");

	public FindStoresPage(WebDriver driver)
	{
		this.driver=driver;
	}
	
	public void clickStores_and_Preschool ()
	{
		driver.findElement(Stores_and_Preschool).click();
		System.out.println("got Stores_and_Preschool");
	}
	public void clickFind_Stores ()
	{
		driver.findElement(Find_Stores).click();
		System.out.println("Found Stores");
	}

}
