package com.pages.RLL_240Testing_FirstCry;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class FindPreschoolsPage {
	WebDriver driver;

	By main_Locator = By.xpath("//span[@class='anch'][contains(text(),'Stores & Preschools')]");
	By find_preschool = By.xpath("//span[@class='anch'][contains(text(),'Find Preschools')]");

	public FindPreschoolsPage(WebDriver driver) {
		this.driver = driver;
	}

	public void clickmain_Locator() {
		driver.findElement(main_Locator).click();
		System.out.println(" Main locator is displayed ");
	}

	public void clickfind_preschool() {
		driver.findElement(find_preschool).click();
		System.out.println("Finds the  preschools ");
	}

}