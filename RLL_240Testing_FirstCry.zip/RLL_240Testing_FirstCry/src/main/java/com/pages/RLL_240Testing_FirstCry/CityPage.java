package com.pages.RLL_240Testing_FirstCry;

import java.util.Iterator;
import java.util.Set;
 
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
 
public class CityPage {
	WebDriver driver;
	By closeButton = By.xpath("(//button[\"close-btn\"])[11]");
	By by_city = By.xpath("//*[@src=\"https://cdn.fcglcdn.com/education/totsweb/production/preschool/jaipur.svg\"]");
 
	
	public CityPage (WebDriver driver)
	{
		this.driver = driver;
	}
 
	public void closeWindowButton() {
		Set<String> windows = driver.getWindowHandles();
		Iterator<String> it = windows.iterator();
		String parent = it.next();
		String child = it.next();
		driver.switchTo().window(child);
		driver.findElement(closeButton).click();
		System.out.println("The window is closed ");
	}
 
	public void searchByCity() {
		driver.findElement(by_city).click();
		System.out.println(" the particular city is selected");
	}
 
}
