package com.pages.RLL_240Testing_FirstCry;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class PincodePage {
	WebDriver driver;
	By txt_pincode = By.xpath("//input[contains(@placeholder,'Search by Pincode')]");
	By submit_btn = By.xpath("//*[@class=\"btn-submit-wrap\"]");

	public  PincodePage(WebDriver driver) {
		this.driver = driver;
	}
	
	public void entertxt_pincode(String  pincode) {
		Set<String> windows = driver.getWindowHandles();
		Iterator<String> it = windows.iterator();
		String parent = it.next();
		String child = it.next();
		driver.switchTo().window(child);
		driver.findElement(txt_pincode).click();
		driver.findElement(txt_pincode).sendKeys(pincode);
	}

	public void clicksubmit_btn() {

		driver.findElement(submit_btn).click();
	}

}