package com.runner.RLL_240Testing_FirstCry;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features = "src/test/resource/com/features",
glue = "com.stepdefinition.RLL_240Testing_FirstCry",
plugin = {"pretty", "html:target/cucumber-reports.html"},
tags = "@HomePage",
monochrome = true
)

public class RunnerTestNG extends AbstractTestNGCucumberTests{
}
