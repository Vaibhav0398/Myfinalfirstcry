package com.stepdefinition.RLL_240Testing_FirstCry;

import java.time.Duration;
import java.util.Iterator;
import java.util.Set;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.pages.RLL_240Testing_FirstCry.CityPage;
import com.pages.RLL_240Testing_FirstCry.FindPreschoolsPage;
import com.pages.RLL_240Testing_FirstCry.HomePage;
import com.pages.RLL_240Testing_FirstCry.PincodePage;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
 
public class StepDefinition_FindPreschools {
 
	WebDriver driver;
	FindPreschoolsPage fpp;
	PincodePage pin;
	CityPage city;
	Logger log;
	HomePage home;
 
	@Before
	public void init() {
		driver = new EdgeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		fpp = new FindPreschoolsPage(driver);
		pin = new PincodePage(driver);
		city = new CityPage(driver);
		home = new HomePage(driver);
		log = Logger.getLogger(StepDefinition_FindPreschools.class);
 
	}
	
	@After
	public void tearDown() {
		driver.quit();
		log.info("Browser closed");
	}
 
	@Given("the user is on the Home page")
	public void the_user_is_on_the_Home_page() throws InterruptedException {
		home.LaunchFirstCry();
		log.info("The user is on Hme Page");
		Thread.sleep(1000);
 
	}
 
	@When("the user clicks on Stores Preschoolsss")
	public void the_user_clicks_on_Stores_Preschools() {
		fpp.clickmain_Locator();
	}
 
	@And("the user clicks on find preschools from the dropdown")
	public void the_user_clicks_on_find_preschools_from_the_dropdown() {
		fpp.clickfind_preschool();
	}
 
	@Then("the user should be able  to navigate to Preschool Locator")
	public void the_user_should_be_able_to_navigate_to_Preschool_Locator() {
		Set<String> windows = driver.getWindowHandles();
		Iterator<String> it = windows.iterator();
		String parent = it.next();
		String child = it.next();
		driver.switchTo().window(child);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		boolean isPreschoolLocatorDisplayed = driver.findElement(By.xpath("//h2[contains(text(),'Preschool Locator')]"))
				.isDisplayed();
		Assert.assertTrue(isPreschoolLocatorDisplayed, "Preschool Locator");
		log.info("user is navigated to the preschool");
	}
 
	@Given("the user opens the Home page")
	public void the_user_opens_the_Home_page() throws InterruptedException {
		home.LaunchFirstCry();
		log.info("user on the home page");
		Thread.sleep(1000);
	}
 
	@When("User clicks find preschool button")
	public void User_clicks_find_preschool_button() {
		fpp.clickmain_Locator();
	}
 
	@And("user click on find preschools from the dropdown")
	public void user_click_on_find_preschools_from_the_dropdown() {
		fpp.clickfind_preschool();
	}
 
	@When("^the user enters pincode(.*)$")
	public void the_user_enters_pincode(String pincode) {
		pin.entertxt_pincode(pincode);
	}
 
	@And("user clicks on the Submit button")
	public void user_clicks_on_the_Submit_button() throws InterruptedException {
		pin.clicksubmit_btn();
		Thread.sleep(2000);
		log.info("User clicked on submit button");
	}
 
	@Then("the user should get result")
	public void the_user_should_get_result() {
// Add verification code here
		/*
		 * WebElement ele =
		 * driver.findElement(By.xpath("//p[contains(text(),'Preschools Near You')]"));
		 * Assert.assertEquals(ele, "Preschools Near You");
		 */
	}
 
	@Given("user is on the firstcry Home page")
	public void user_is_on_the_firstcry_Home_page() throws InterruptedException {
		home.LaunchFirstCry();
		Thread.sleep(1000);
		log.info("User is in fristcry homepage");
	}
 
	@When("User press find preschool button")
	public void User_press_find_preschool_button() throws InterruptedException {
		fpp.clickmain_Locator();
		Thread.sleep(1000);
	}
 
	@And("user press on find preschools from the dropdown")
	public void user_press_on_find_preschools_from_the_dropdown() throws InterruptedException {
		Thread.sleep(1000);
		fpp.clickfind_preschool();
	}
 
	@When("the user closes the preschool locator window")
	public void the_user_closes_the_preschool_locator_window() throws InterruptedException {
		Thread.sleep(2000);
		city.closeWindowButton();
		log.info("User closed the preschool locator ");
	}
 
	@And("the user selects the required city")
	public void the_user_selects_the_required_city() throws InterruptedException {
		city.searchByCity();
		log.info("User selected the required city");
		Thread.sleep(2000);
	}
 
	@Then("the user should be able to find the list of preschool details in the selected city")
	public void the_user_should_be_able_to_find_the_list_of_preschool_details_in_the_selected_city() {
		/*
		 * // Add verification code here WebElement byCity = driver.findElement(By.
		 * xpath("//h1[contains(text(),'FirstCry Intellitots Preschools In chennai')]"))
		 * ; Assert.assertEquals(byCity, "FirstCry Intellitots Preschools In chennai");
		 */
// @Then("the user should be able to find the list of preschool details in the selected city")
// public void the_user_should_be_able_to_find_the_list_of_preschool_details_in_the_selected_city() {
		// Locate the WebElement that contains the heading text
		WebElement byCity = driver
				.findElement(By.xpath("//h1[contains(text(),'FirstCry Intellitots Preschools In jaipur')]"));
 
		// Get the text from the WebElement
		String actualText = byCity.getText();
 
		// Assert that the actual text matches the expected text
		String expectedText = "FirstCry Intellitots Preschools In Jaipur";
		Assert.assertEquals(actualText, expectedText, "Text should match the expected value");
	}
 
}

