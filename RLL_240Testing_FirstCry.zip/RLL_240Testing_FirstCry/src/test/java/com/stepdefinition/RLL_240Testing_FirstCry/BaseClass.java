package com.stepdefinition.RLL_240Testing_FirstCry;
import java.io.File;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.google.common.io.Files;

public class BaseClass {
	 public static WebDriver driver;
	
	static ExtentReports ext1; // class 
	static ExtentTest test;//interface
	static ExtentHtmlReporter testreport;
	
	public static void initialize() throws InterruptedException {
		
        driver = new ChromeDriver();
		driver.get("https://www.google.com");
		
		testreport = new ExtentHtmlReporter("./ExtentsHtmlReports/sampleexecutionreport.html"); // path
		ext1=new ExtentReports(); // object
	
		test = ext1.createTest("user.dir", "test");

		
	}
	
	public void captureScreenShots(String methodname) {
		
		try
		{
			File file = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		    Files.copy(file, new File("./images/p.jpg"));
		    
		
		}
		catch(Exception e) {
			e.getMessage();
		
		}
		
	}
  
}

