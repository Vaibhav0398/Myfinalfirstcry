package com.stepdefinition.RLL_240Testing_FirstCry;

import java.time.Duration;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.pages.RLL_240Testing_FirstCry.FindStoresPage;
import com.pages.RLL_240Testing_FirstCry.HomePage;
import com.pages.RLL_240Testing_FirstCry.SelectingDataPage;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefinition_SelectingData {
	WebDriver driver;
	FindStoresPage fstore;
	SelectingDataPage data;
	Logger log;
	HomePage home;
	
	@Before
	public void init() {
		driver= new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
		fstore=new FindStoresPage(driver);
		data = new SelectingDataPage(driver);
		home = new HomePage(driver);
		log = Logger.getLogger(StepDefinition_SelectingData.class);

	}
	
	@After
	public void tearDown() {
		driver.quit();
		log.info("Browser closed");
	}
	
	@Given("the user opens the home page")
	public void the_user_opens_the_home_page() throws InterruptedException {
		home.LaunchFirstCry();
		log.info("the user opens the home page");
	}

	@When("the user press to the Stores Preschools")
	public void the_user_press_to_the_Stores_Preschools() throws InterruptedException {
		fstore.clickStores_and_Preschool();
		log.info("the user press to the Stores Preschools");
	}

	@And("the user press on find stores button")
	public void the_user_press_on_find_stores_button() throws InterruptedException {
		fstore.clickFind_Stores();
		log.info("the user press on find stores button");
	}

	@When("^the user selects StoreType(.*)$")
	public void the_user_selects_StoreType(String store) throws InterruptedException {
		data.selectStore_Type(store);
		log.info("the user selects StoreType");
	}

	@When("^the user selects State(.*)$")
	public void the_user_selects_State(String State) {
		data.selectState(State);
		log.info("the user selects State");
	}

	@When("^the user selects City(.*)$")
	public void the_user_selects_City(String City) throws InterruptedException {
		data.selectCity(City);
		log.info("the user selects City");
	}

	@When("the user clicks on Search")
	public void the_user_clicks_on_search() throws InterruptedException {
		data.clickSearch();
		log.info("the userclicks on search");
	}

	@Then("the user should display result")
	public void the_user_should_display_result() {
		System.out.println("Result");
		log.info("the user gets result");

	}

}
