package com.stepdefinition.RLL_240Testing_FirstCry;

import java.time.Duration;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.pages.RLL_240Testing_FirstCry.FindStoresPage;
import com.pages.RLL_240Testing_FirstCry.HomePage;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefinition_FindStores {
	WebDriver driver;
	FindStoresPage fstore;
	Logger log;
	WebDriverWait wait;
	HomePage home;

	@Before
	public void init() {
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		fstore = new FindStoresPage(driver);
		home = new HomePage(driver);
		log = Logger.getLogger(StepDefinition_FindStores.class);

	}
	
	@After
	public void tearDown() {
		driver.quit();
		log.info("Browser closed");
	}

	@Given("the user is on Home Page")
	public void the_user_is_on_home_page() throws InterruptedException {
		home.LaunchFirstCry();
		Thread.sleep(2000);
		log.info("user is on Home Page");
	}

	@When("the user clicks on Stores Preschools")
	public void the_user_clicks_on_Stores_Preschools() throws InterruptedException {
		fstore.clickStores_and_Preschool();
		Thread.sleep(2000);
		log.info("user clicks on Stores Preschools");
	}

	@And("the user then click on find store button")
	public void the_user_then_click_on_find_store_button() throws InterruptedException {
		fstore.clickFind_Stores();
		Thread.sleep(2000);
		log.info("user clicked on find store button");
	}

	@Then("the user will be navigate to the store locator page")
	public void the_user_will_be_navigate_to_the_store_locator_page() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		WebElement findStoresButton = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@class='anch'][contains(text(),'Find Stores')]")));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", findStoresButton);

		String actualUrl = driver.getCurrentUrl();
		System.out.println(actualUrl);
		String expectedUrl = "https://www.firstcry.com/store-locator?ref2=topstrip";
		Assert.assertEquals("User should be navigated to Store Locator page", expectedUrl, actualUrl);

		log.error("Store Locator page is displayed and text is not verified.");

	}

}
