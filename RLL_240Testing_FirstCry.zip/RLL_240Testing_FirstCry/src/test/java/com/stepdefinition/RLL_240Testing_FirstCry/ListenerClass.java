package com.stepdefinition.RLL_240Testing_FirstCry;

import org.testng.ITestListener;
import org.testng.ITestResult;
import org.testng.annotations.Test;

public class ListenerClass extends BaseClass implements ITestListener {
	@Test
	public void onTestFailure(ITestResult result) {
		try{captureScreenShots(result.getName());
		}
		catch(Exception e) {
			e.getMessage();
		}
		
	}

}
